# group2cashieringsystem


need to make into a cashiering system instead of an inventory system
